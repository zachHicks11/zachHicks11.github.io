debugger;
document.write("This page is Copyright " + new Date().getFullYear());